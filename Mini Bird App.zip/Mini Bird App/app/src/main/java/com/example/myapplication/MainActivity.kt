package com.example.myapplication

import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    lateinit var score : TextView
    private val sharedPrefFile = "sharedFile"
    private var sharedPreferences: SharedPreferences? = null

    var sc :Int = 0;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
         score = findViewById(R.id.tvScore)
        val teal : Button = findViewById(R.id.btTealt)
        val black : Button = findViewById(R.id.btBlack)
        val purple : Button = findViewById(R.id.btPurple)
        val white : Button = findViewById(R.id.btWhite)
        val reset : Button = findViewById(R.id.btReset)
        sharedPreferences = this.getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)
        showScore()
        teal.setOnClickListener {
            scoreFunc("#FF03DAC5")
        }
        black.setOnClickListener {
            scoreFunc("#FF000000")
        }
        purple.setOnClickListener {
            scoreFunc("#FFBB86FC")
        }
        white.setOnClickListener {
            scoreFunc("#ffffff")
        }
        reset.setOnClickListener {

            reset()
        }

    }
    fun scoreFunc(color:String)
    {
        sc +=1

        score.text = sc.toString()

        tvScore.setTextColor(Color.parseColor(color))

        Log.i("data", sc.toString())
        Log.i("color", color)

        val editor:SharedPreferences.Editor =  sharedPreferences!!.edit()
        editor.putInt("score", sc)
        editor.putString("color", color)

        editor.apply()
        editor.commit()


    }
    fun reset()
    {

        val editor = sharedPreferences!!.edit()
        editor.clear()
        editor.apply()
        showScore()
    }
    fun showScore()
    {
        val totalScore = sharedPreferences!!.getInt("score",0)
        val storeColor = sharedPreferences!!.getString("color","#4868ea")

        sc = totalScore
        score.text = sc.toString()
        score.setTextColor(Color.parseColor(storeColor))

    }
}

